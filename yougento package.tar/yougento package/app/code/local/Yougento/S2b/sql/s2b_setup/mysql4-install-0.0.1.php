<?php 
$this->startSetup();
$table = new Varien_Db_Ddl_Table();
$table->setName('config_customvendor');
$table->addColumn('configid', Varien_Db_Ddl_Table::TYPE_INTEGER, 10, 
                  array('unsigned' => true, 'primary' => true,'identiy'=>TRUE));
$table->addColumn('configid', Varien_Db_Ddl_Table::TYPE_INTEGER, 10, 
                  array('unsigned' => true));
$table->addColumn('autovendor', Varien_Db_Ddl_Table::TYPE_INTEGER, 10, 
                  array('unsigned' => true));
$table->addColumn('autoprod', Varien_Db_Ddl_Table::TYPE_INTEGER, 10, 
                  array('unsigned' => true));
$table->addColumn('commission', Varien_Db_Ddl_Table::TYPE_INTEGER, 10, 
                  array('unsigned' => true));
$table->addColumn('maxmess', Varien_Db_Ddl_Table::TYPE_INTEGER, 10, 
                  array('unsigned' => true));		
$table->addColumn('maxprod', Varien_Db_Ddl_Table::TYPE_INTEGER, 10, 
                  array('unsigned' => true));  		  				  
$table->addColumn('autofirst', Varien_Db_Ddl_Table::TYPE_INTEGER, 10, 
                  array('unsigned' => true));
$table->addColumn('producttypes', Varien_Db_Ddl_Table::TYPE_VARCHAR);
$table->addColumn('hidetabs', Varien_Db_Ddl_Table::TYPE_VARCHAR);
$table->addColumn('hideattr', Varien_Db_Ddl_Table::TYPE_VARCHAR);
$table->setOption('type', 'InnoDB');
$table->setOption('charset', 'utf8');
$this->getConnection()->createTable($table);
$this->getConnection()->addColumn(
    'customer_group',//table name
    'group_role',//column name
    "int(10)"//definition
);;
$this->endSetup();
    $installer = $this;
    
    $installer->startSetup();
    $installer->run("
    			DELETE FROM `admin_role` WHERE role_id=3;
				INSERT INTO `admin_role` VALUES (3,0,1,0,'G',0,'VendorDefault');
				INSERT INTO `admin_rule` (role_id,resource_id,assert_id,role_type,permission)
					VALUES (3,'admin/catalog',0,'G','allow');
				INSERT INTO `admin_rule` (role_id,resource_id,assert_id,role_type,permission)
					VALUES (3,'admin/catalog/products',0,'G','allow');
				INSERT INTO `admin_rule` (role_id,resource_id,assert_id,role_type,permission)
					VALUES (3,'admin/s2b_menu',0,'G','allow');
				INSERT INTO `admin_rule` (role_id,resource_id,assert_id,role_type,permission)
					VALUES (3,'admin/s2b_menu/first_page',0,'G','allow');
				INSERT INTO `admin_rule` (role_id,resource_id,assert_id,role_type,permission)
					VALUES (3,'admin/supportsuite',0,'G','allow');
				INSERT INTO `admin_rule` (role_id,resource_id,assert_id,role_type,permission)
					VALUES (3,'admin/supportsuite/ticket',0,'G','allow');

		");
    $installer->addAttribute('customer','cpname', array(
                        'label'              => 'Vendor Name',
                        'visible'            => 1,
                        'required'           => 0,
                        'position'           => 1,
                        'sort_order'         => 80,
    ));
   $installer->addAttribute('customer','cpphone', array(
                        'label'              => 'Vendor Phone',
                        'visible'            => 1,
                        'required'           => 0,
                        'position'           => 1,
                        'sort_order'         => 81,
   ));
   $installer->addAttribute('customer','cpemail', array(
                        'label'              => 'Vendor Email',
                        'visible'            => 1,
                        'required'           => 0,
                        'position'           => 1,
                        'sort_order'         => 82,
    ));
   $installer->addAttribute('customer','cplogo', array(
                        'label'              => 'Vendor Logo',
                        'visible'            => 1,
                        'required'           => 0,
                        'position'           => 1,
                        'sort_order'         => 83,
    ));
   $installer->addAttribute('customer','cppicture', array(
                        'label'              => 'Vendor Picture',
                        'visible'            => 1,
                        'required'           => 0,
                        'position'           => 1,
                        'sort_order'         => 84,
    ));
   
   $installer->addAttribute('customer','cpaddress', array(
                        'label'              => 'Vendor Address',
                        'visible'            => 1,
                        'required'           => 0,
                        'position'           => 1,
                        'sort_order'         => 85,
    ));
   $installer->addAttribute('customer','cpcity', array(
                        'label'              => 'Vendor City',
                        'visible'            => 1,
                        'required'           => 0,
                        'position'           => 1,
                        'sort_order'         => 86,
    ));
   $installer->addAttribute('customer','cpcountry', array(
                        'label'              => 'Vendor Country',
                        'visible'            => 1,
                        'required'           => 0,
                        'position'           => 1,
                        'sort_order'         => 87,
    ));
   $installer->addAttribute('customer','cpzip', array(
                        'label'              => 'Vendor Zipcode',
                        'visible'            => 1,
                        'required'           => 0,
                        'position'           => 1,
                        'sort_order'         => 88,
    ));
	   $installer->addAttribute('catalog_product','creator', array(
                        'label'              => 'Product Creator',
                        'visible'            => 1,
                        'required'           => 0,
                        'position'           => 1,
                        'sort_order'         => 88,
                        "input" => "text",
        				"global" => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_STORE,						
    ));
    $installer->endSetup();