<?php
class Yougento_S2b_Model_Mysql4_Information_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
{
	public function _construct()
	{
		$this->_init('s2b/information');
	}

}