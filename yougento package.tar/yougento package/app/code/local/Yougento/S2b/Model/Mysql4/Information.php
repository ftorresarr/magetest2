<?php
class Yougento_S2b_Model_Mysql4_Information extends Mage_Core_Model_Mysql4_Abstract
{

	public function _construct()
	{

		$this->_init('s2b/information','infoid');
	}

}