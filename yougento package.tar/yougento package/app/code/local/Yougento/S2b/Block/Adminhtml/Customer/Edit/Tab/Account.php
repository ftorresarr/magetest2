<?php /*
class Yougento_S2b_Block_Adminhtml_Edit_Form extends Mage_Adminhtml_Block_Customer_Edit_Tab_Account
{
	public function initForm()
	{
		$form = new Varien_Data_Form();
		$fieldset = $form->addFieldset('vendor_fieldset',
				array('legend'=>Mage::helper('customer')->__('Vendor Settings'))
		);
		$fieldset->addField('acctype', 'text',
				array(
						'label' => Mage::helper('customer')->__('Account Type'),
						'class' => 'input-text',
						'name'  => 'acctype',
						'required' => false
				)
		);
		$this->setForm($form);
		echo "hiiiiiiii";
		return $this;
	}
} */