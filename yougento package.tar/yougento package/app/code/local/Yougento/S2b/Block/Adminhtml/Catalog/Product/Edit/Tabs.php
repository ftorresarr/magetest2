<?php
class Yougento_S2b_Block_Adminhtml_Catalog_Product_Edit_Tabs extends Mage_Adminhtml_Block_Catalog_Product_Edit_Tabs
{
	 
	protected function _prepareLayout(){
		parent::_prepareLayout();
		$roleId = implode('', Mage::getSingleton('admin/session')->getUser()->getRoles());
		$customConfig = Mage::getModel('s2b/configs')->load($roleId,'vroleid');
		$hideTabs = $customConfig->getHidetabs();
		if($hideTabs){
			$hideTabs = $customConfig->getHidetabs();
		}
		foreach ((array)explode(",", $hideTabs) as $tab){
			$this->removeTab($tab);
		}
		 
		return $this;
	}


}