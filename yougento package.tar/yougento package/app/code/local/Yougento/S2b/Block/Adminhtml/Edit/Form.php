<?php 
class Yougento_S2b_Block_Adminhtml_Edit_Form extends Mage_Adminhtml_Block_Widget_Form
{
	
	protected function _prepareForm()
    {
    	
    	$config = Mage::getModel('s2b/configs')->load($this->getRequest()->getParam('rid'),'vroleid');
    	$autoproduct = $config->getAutoprod();
    	if($autoproduct){
    		$autoproduct = $config->getAutoprod();
    	}else{
    		$autoproduct = NULL;
    	}
    	$autofirst=$config->getAutofirst();
    	if ($autofirst) {
    		$autofirst=$config->getAutofirst();
    	}else{
    		$autofirst = NULL;
    	}
    	$maxmess = $config->getMaxmess();
    	if($maxmess){
    		$maxmess =$config->getMaxmess();
    	}else {
    		$maxmess = NULL;
    	}
    	$maxprod = $config->getMaxprod();
    	if($maxprod){
    		$maxprod =$config->getMaxprod();
    	}else {
    		$maxprod = NULL;
    	}
    	$comission = $config->getCommission();
    	if($comission){
    		$comission =$config->getCommission();
    	}else {
    		$comission = NULL;
    	}
    	$prodtypes = $config->getProducttypes();
    	if($prodtypes){
    		$prodtypes =$config->getProducttypes();
    	}else {
    		$prodtypes = NULL;
    	}
    	$hidetabs = $config->getHidetabs();
    	if($hidetabs){
    		$hidetabs =$config->getHidetabs();
    	}else {
    		$hidetabs = NULL;
    	}
    	$hideattr=$config->getHideattr();
		if($hideattr){
			$hideattr=$config->getHideattr();
		}else{
			$hideattr=NULL;
		}
        $form = new Varien_Data_Form();
 
        $fieldset = $form->addFieldset('vendor_resources', array('legend' => Mage::helper('s2b')->__('Modify individual vendor role settings')));
 		
        $fieldset->addField('roleid', 'hidden', array(
        		'label'     => Mage::helper('s2b')->__('Role ID'),
        		'name'      => 'roleid',
        		'value'  	=> $this->getRequest()->getParam('rid'),
        		'disabled' 	=> false,
        		'readonly' 	=> true,
        ));

		
		
		$fieldset->addField('autoproduct', 'select', array(
				'label'     => Mage::helper('s2b')->__('Approve Products Automatically'),
				'required'  => false,
				'name'      => 'autoproduct',
				'onclick' => "",
				'onchange' => "",
				'value'=> $autoproduct,
				'values' => array(
						'-1'=>'Please Select..',
						'1' => array(
								'value'=> array(array('value'=>'1' , 'label' => 'Yes') , array('value'=>'0' , 'label' =>'No') ),
								'label' => ''
						),
		
				),
				'disabled' => false,
				'readonly' => false,
		));
        
  /*      $fieldset->addField('maxmess', 'text', array(
            'name'      => 'maxmess',
            'title'     => Mage::helper('s2b')->__('maxmess'),
            'label'     => Mage::helper('s2b')->__('Vendor Maximum Allowed Messages'),
            'maxlength' => '250',
        	'value'=> $maxmess,
            'required'  => false,
        	'after_element_html' => '<small>0 - no minimum limits</small>',
        ));*/
 
        $fieldset->addField('maxprod', 'text', array(
            'name'      => 'maxprod',
            'title'     => Mage::helper('s2b')->__('maxprod'),
            'label'     => Mage::helper('s2b')->__('Vendor Maximum Products'),
            'maxlength' => '250',
        	'value'=> $maxprod,
            'required'  => false,
        	'after_element_html' => '<small>0 - no maximum limits</small>',
        ));
        
        $fieldset->addField('commission', 'text', array(
        		'name'      => 'commission',
        		'title'     => Mage::helper('s2b')->__('commission'),
        		'label'     => Mage::helper('s2b')->__('Default Store Comission'),
        		'maxlength' => '250',
        		'value'=> $comission,
        		'required'  => false,
        ));
        $entityType = Mage::getModel('catalog/product')->getResource()->getEntityType();
        $collection = Mage::getResourceModel('eav/entity_attribute_set_collection')
        ->setEntityTypeFilter($entityType->getId());
        
        $result = array();
        foreach ($collection as $attributeSet) {

        	array_push($result,array('value'=>$attributeSet->getId(),'label'=>$attributeSet->getAttributeSetName()));

        }
        $fieldset->addField('hideattr', 'multiselect', array(
        		'label'     => Mage::helper('s2b')->__('Hide Attribute Set'),
        		'required'  => false,
        		'name'      => 'hideattr',
        		'onclick' => "return false;",
        		'value'=> $hideattr,
        		'onchange' => "return false;",
        		'values' => array(
        				'1' => array(
        						'value'=> $result, 'label' => ''
        
        				)),
        		'disabled' => false,
        		'readonly' => false,
        ));
        
        $fieldset->addField('producttypes', 'multiselect', array(
        		'label'     => Mage::helper('s2b')->__('Available Product Types'),
        		'required'  => false,
        		'name'      => 'producttypes',
        		'onclick' => "return false;",
        		'value'=> $prodtypes,
        		'onchange' => "return false;",
        		'values' => array(
        				'1' => array(
        						'value'=> array(array('value'=>'NULL' , 'label' => 'All') , array('value'=>'simple' , 'label' =>'Simple Product'),
        								array('value'=>'grouped' , 'label' => 'Grouped Product' ), array('value'=>'configurable' , 'label' => 'Configurable Product' ),
        								array('value'=>'virtual' , 'label' => 'Virtual Product' ), array('value'=>'bundle' , 'label' => 'Bundle Product' ),
        								array('value'=>'downloadable' , 'label' => 'Downloadable Product' )), 'label' => ''
        
        				)),
        		'disabled' => false,
        		'readonly' => false,
        		'after_element_html' => '<small>At least one product type should be selected<small>',
        ));
 
        $fieldset->addField('hidetabs', 'multiselect', array(
          'label'     => Mage::helper('s2b')->__('Hide Tabs'),
          'required'  => false,
          'name'      => 'hidetabs',
          'onclick' => "return false;",
          'onchange' => "return false;",
        		'value'=> $hidetabs,
          'values' => array(
                                '1' => array(
                                                'value'=> array(array('value'=>'NULL' , 'label' => 'None') ,array('value'=>'inventory' , 'label' => 'Inventory') , array('value'=>'websites' , 'label' =>'Websites'),
                                                				array('value'=>'categories' , 'label' => 'Categories' ), array('value'=>'related' , 'label' => 'Related Products' ),
                                                				array('value'=>'upsell' , 'label' => 'Up-Sells' ), array('value'=>'crosssell' , 'label' => 'Cross-Sells' ),
                                                				array('value'=>'productalert' , 'label' => 'Product Alerts' ), array('value'=>'reviews' , 'label' => 'Product Reviews' ),
                                                				array('value'=>'tags' , 'label' => 'Product Tags' ), array('value'=>'customers_tags' , 'label' => 'Customers Tagged Products' ), 
                                           	                    array('value'=>'customer_options' , 'label' => 'Custom Options' )), 'label' => ''    
 
                           )),
          'disabled' => false,
          'readonly' => false,
        ));
 		$form->setMethod('post');
        $form->setUseContainer(true);
        $form->setId('edit_form');
        $form->setAction($this->getUrl('*/*/save'));
 
        $this->setForm($form);
        $id = $this->getRequest()->getParam('rid');
    }

	
	protected function _prepareLayout()
	{
		$role = Mage::registry('current_role');

	
		return parent::_prepareLayout();
	}
}
?>
