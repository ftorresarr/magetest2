<?php
class Yougento_S2b_Block_Adminhtml_Customer_Group_Edit extends Mage_Adminhtml_Block_Customer_Group_Edit
{
	
}